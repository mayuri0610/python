from django.apps import AppConfig


class FacebookAuthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'facebook_auth'
