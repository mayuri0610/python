


QUESTION_CHOICES = (
    ('short answer' , 'short answer'),
    ('long answer' , 'long answer'),
    ('multiple choice' , 'multiple choice'),
    ('checkbox' , 'checkbox'),
    )