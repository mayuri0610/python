# Default Arguments

# Sometime we mention default value to the formal argument in function definition and we may not required to provide actual argument, In this case default argument will be used by formal argument.
# If we do not provide actual argument for formal argument explicitly while calling the function then formal argument will use default value on the other hand if we provide actual argument then it will use provided value




# def Arithmatic(a=0,b=0):
#     print(a+b)

# Arithmatic(10)




# def Arithmatic(a=100,b=0):
#     print(a+b)

# Arithmatic()



def Arithmatic(a=0,b=0):
    print(a+b)

Arithmatic(10,20)