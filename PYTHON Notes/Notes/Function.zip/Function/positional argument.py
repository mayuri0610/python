# Positional Arguments

# These arguments are passed to the function in correct positional order. 
# The number of arguments and their positions in the function definition should be equal to the number and position of the argument in the function call.



def Arithmatic(a,b):
    print(a+b)

Arithmatic(10,20)


