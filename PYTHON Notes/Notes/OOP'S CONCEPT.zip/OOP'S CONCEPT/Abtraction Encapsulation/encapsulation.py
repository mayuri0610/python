# Encapsulation : Encapsulation means bindind or wrapping data together into single unit.
#     it is a colletion of attribute and function 
#     It is used for Security purpose.
#     By using Classes we can achieve Encapsulation.



