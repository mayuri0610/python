from rest_framework import serializers
from .models import *

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = '__all__'
        # fields = ['user', 'full_name', 'bio', 'profile_picture']

    # def user_get(self,obj):
    #     obj = User.objects.filter(id=obj.id)
    #     userobj = User.objects.get(id=obj)
    #     return userobj.username
    
class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Post
        fields = '__all__'

class CommentSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Comment
        fields = '__all__'


class likeSerializer(serializers.ModelSerializer):

    class Meta:
        models = Like
        fields = '__all__'