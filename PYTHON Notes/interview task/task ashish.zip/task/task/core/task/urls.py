

from django.urls import path
from .views import *

urlpatterns = [
    path('register', RegistrationAPI.as_view(), name='register'),
    path('login', LoginAPI.as_view(), name='login'),

    path('profile', UserProfileView.as_view(), name='profile'),
    path('profile/<int:id>', UserProfileView.as_view(), name='profile'),

    path('post', PostView.as_view(), name='post'),
    path('post/<int:id>', PostView.as_view(), name='post'),

    path('comment', CommentCreateView.as_view(), name='comment'),
    path('comment/<int:id>', CommentCreateView.as_view(), name='comment'),

    path('LikeAPI', LikeAPI.as_view(), name='LikeAPI'),
    path('LikeAPI/<int:id>', LikeAPI.as_view(), name='LikeAPI'),
    
]
