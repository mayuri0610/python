
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from .models import *
from .serializers import *
from .import util


# class UserRegistrationView(APIView):
#     def post(self, request,format=None):
#         username = request.data.get('username')
#         password = request.data.get('password')
#         c_password = request.data.get('c_password')
        
#         if username is not None and password is not None and c_password is not None:
#             if User.objects.filter(username=username).exists():
#                 return Response({'error': 'Username already exists.'}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 if password == c_password:
#                     user = User.objects.create_user(username=username, password=password)
#                     print(user)
#                     return Response({'message': 'User registered successfully.'}, status=status.HTTP_201_CREATED)
#                 else:
#                     return Response({'error': 'Passwords do not match.'}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({'error': 'Incomplete data provided.'}, status=status.HTTP_400_BAD_REQUEST)

# class UserLoginView(APIView):
#     def post(self, request):
#         username = request.data.get('username')
#         password = request.data.get('password')
        
#         if username is not None and password is not None:
#             user = authenticate(username=username, password=password)
#             if user is not None:
#                 login(request, user)
#                 return Response({'message': 'Login successful.'}, status=status.HTTP_200_OK)
#             else:
#                 return Response({'error': 'Invalid credentials.'}, status=status.HTTP_401_UNAUTHORIZED)
#         else:
#             return Response({'error': 'Incomplete data provided.'}, status=status.HTTP_400_BAD_REQUEST)


class RegistrationAPI(APIView):
    def post(self, request, format=None):
        try:
            email=request.data.get('email')
            password=request.data.get('password')
            conform_password=request.data.get('conform_password')
            if email != None and password != None and conform_password != None :
                if password == conform_password:
                    if User.objects.filter(username=email).exists():
                        return Response(util.error(self,'User already exist with this email address'))
                    else:
                        User.objects.create( username=email, password=password)
                        return Response(util.success(self,'The Registration is successfully'))
                else:
                    return Response(util.error(self,'Password is Not match'))
            else:
                return Response(util.error(self,'email,password,conform_password is needed'))
        except Exception as e :
            return Response(util.error(self,str(e))) 
        
class LoginAPI(APIView):
    def post(self, request, format=None):
        try:
            email = request.data.get('email')
            password = request.data.get('password')
            user = authenticate(username=email, password=password)
            if user is not None:
                login(request, user)
                return Response("Login successful", status=status.HTTP_200_OK)
            else:
                return Response("Invalid credentials", status=status.HTTP_401_UNAUTHORIZED)
        except Exception as e:
            return Response(util.error(self,str(e)))
        
class UserProfileView(APIView):

    def post(self, request , format=None):
        try:
            userid=request.POST.get('userid')
            full_name=request.POST.get('full_name')
            bio=request.POST.get('bio')
            profile_picture=request.FILES.get('profile_picture')

            if userid != None and full_name != None and bio != None and profile_picture != None:
                if User.objects.filter(id=userid).exists():
                    if UserProfile.objects.filter(full_name=full_name).exists():
                        return Response(util.error(self,'data in allrdy in database.'))
                    else:
                        userobj=User.objects.get(id=userid)
                        UserProfile.objects.create(user=userobj, full_name=full_name, bio=bio, profile_picture=profile_picture)
                        return Response(util.success(self,'User profile created successfully.'))
                else:
                    return Response(util.error(self,'User profile not valid.'))
            else:
                return Response(util.error(self,'userid,full_name,bio,profile_picture is needed'))
        except Exception as e:
            return Response (util.error(self,str(e)))
    
    def get(self, request,fomate=None,id = None):
        try:
            if id is not None:
                if UserProfile.objects.filter(id=id):
                    userproobj=UserProfile.objects.get(id=id)
                    postobj=Post.objects.filter(user=userproobj) 
                    userserializer=UserProfileSerializer(userproobj)
                    postserializer=PostSerializer(postobj,many=True)

                    add_data={
                        'UserProfile':userserializer.data,
                        'Post':postserializer.data,
                    }
                    return Response(add_data)
                else:
                    return Response(util.error(self,'User Profile Id Not Match'))
            else:
                return Response(util.error(self,"Enter User Profile Id "))
        except Exception as e :
            return Response(util.error(self,str(e)))
         
    def put(self, request, format=None,id=None):
        try:
            if id is not None:
                if UserProfile.objects.filter(id=id):
                    userobj= UserProfile.objects.get(id=id)

                    userid=request.POST.get('userid')
                    full_name=request.POST.get('full_name')
                    bio=request.POST.get('bio')
                    profile_picture=request.FILES.get('profile_picture')

                    if full_name != None :
                        userobj.full_name=full_name

                    if bio != None :
                        userobj.bio=bio

                    if profile_picture != None :
                        userobj.profile_picture=profile_picture

                    userobj.save()
                    return Response(util.success(self,"User profile is successfully updated"))
                else:
                    return Response(util.error(self,"User profile Id Not Match"))
            else:
                return Response(util.error(self,"Enter User profile id"))
        except Exception as e:
            return Response(util.error(self,str(e))) 

    def delete(self, request, format=None,id=None):
        try:
            if id is not None:
                if UserProfile.objects.filter(id=id):
                    obj=UserProfile.objects.get(id=id)
                    obj.delete()
                    return Response(util.success(self,'User Profile is successfully deleted'))
                else:
                    return Response(util.error(self,"User Profile Id Not Match"))
            else :
                return Response(util.error(self,"Enter a user profile id "))
        except Exception as e:
            return Response(util.error(self,str(e)))   
        

class PostView(APIView):

    def post(self, request,fomate=None):
        try:
            userid=request.POST.get('userid')
            content=request.POST.get('content')
            image=request.FILES.get('image')

            if userid != None and content != None and image != None :
                if UserProfile.objects.filter(id=userid): 
                    userobj=UserProfile.objects.get(id=userid)
                    Post.objects.create(user=userobj,content=content,image=image)
                    return Response(util.success(self,'The Post is successfully'))
                else:   
                    return Response(util.error(self,'User Id Not Match'))
            else:
                return Response(util.error(self,'userid,content,image,timestamp is needed'))
        except Exception as e :
            return Response(util.error(self,str(e))) 

    def get(self, request,fomate=None,id = None):
        try:
            if id is None:
                postobj = Post.objects.all()
                serializer = PostSerializer(postobj, many=True)
                return Response(serializer.data)
            else:
                if Post.objects.filter(id=id):
                    postsobj=Post.objects.get(id=id)
                    postserializer=PostSerializer(postsobj)
                    # commentobj= Comment.objects.filter(post=postsobj)
                    # likeobj= Like.objects.filter(post=postsobj)
                    # commentserializer=CommentSerializer(commentobj)
                    # likeserializer=likeSerializer(likeobj)

                    # all_data = {
                    #     "post":postserializer.data,
                    #     "comment":commentserializer.data,
                    #     "like":likeserializer.data
                    # }
                    return Response(postserializer)
                    # return Response(all_data)
                else:
                    return Response(util.error(self,'Post Id Not Match'))
        except Exception as e :
            return Response(util.error(self,str(e)))

    def delete(self, request, format=None,id=None):
        try:
            if id is not None:
                if Post.objects.filter(id=id):
                    obj=Post.objects.get(id=id)
                    obj.delete()
                    return Response(util.success(self,'Post is successfully deleted'))
                else:
                    return Response(util.error(self,"Post Id Not Match"))
            else :
                Postobj=Post.objects.all().delete
                return Response(util.success(self,"Post is successfully deleted"))
        except Exception as e:
            return Response(util.error(self,str(e)))

    def put(self, request, format=None,id=None):
        try:
            if id is not None:
                if Post.objects.filter(id=id):
                    postobj= Post.objects.get(id=id)
                    userid=request.POST.get('userid')
                    content=request.POST.get('content')
                    image=request.FILES.get('image')
                    timestamp=request.POST.get('timestamp')

                    if content != None :
                        postobj.content=content

                    if image != None :
                        postobj.image=image

                    if timestamp != None :
                        postobj.timestamp=timestamp

                    postobj.save()
                    return Response(util.success(self,"Post is successfully updated"))
                else:
                    return Response(util.error(self,"Post Id Not Match"))
            else:
                return Response(util.error(self,"Enter Post id"))
        except Exception as e:
            return Response(util.error(self,str(e))) 

class CommentCreateView(APIView):

    def post(self, request, format=None):
        try:
            vars = request.data
            userid = vars.get('userid')
            postid = vars.get('postid')
            content = vars.get('content')
            timestamp = vars.get('timestamp')
        
            if userid != None and postid != None and content != None  and timestamp != None:
                if UserProfile.objects.filter(id=userid).exists():
                    if Post.objects.filter(id=postid).exists():
                        userobj= UserProfile.objects.get(id=userid)
                        postobj= Post.objects.get(id=postid)
                        Comment.objects.create(user=userobj,post=postobj,content=content,timestamp=timestamp)
                        return Response(util.success(self,'Comment is successfully created'))
                    else:
                        return Response(util.error(self,'Post Id Not Match'))
                else:
                    return Response(util.error(self,'User Id Not Match'))
            else:
                return Response(util.error(self,'userid,postid,content,timestamp is needed.'))
        except Exception as e:
            return Response(util.error(self,str(e))) 
    
    def delete(self, request, format=None,id=None):
        try:
            if id is not None:
                if Comment.objects.filter(id=id):
                    obj=Comment.objects.get(id=id)
                    obj.delete()
                    return Response(util.success(self,'Comment is successfully deleted'))
                else:
                    return Response(util.error(self,"comment Id Not Match"))
            else :
                commentobj=Comment.objects.all().delete
                return Response(util.success(self,"Comment is successfully deleted"))
        except Exception as e:
            return Response(util.error(self,str(e)))

    def get(self, request, format=None,id=None):
        try:
            if id is None :
                obj=Comment.objects.all()
                serializerobj=CommentSerializer(obj, many=True)
                return Response(serializerobj.data)
            else :
                if Comment.objects.filter(id=id):
                    obj=Comment.objects.get(id=id)
                    serializerobj=CommentSerializer(obj).data
                    return Response(serializerobj)
                else:
                    return Response(util.error(self,"Comment Id Not Match"))
        except Exception as e:
            return Response(util.error(self,str(e))) 

    def put(self, request, format=None,id=None):
        try:
            if id is not None:
                if Comment.objects.filter(id=id):
                    commentobj= Comment.objects.get(id=id)
                    vars = request.data
                    userid = vars.get('userid')
                    postid = vars.get('postid')
                    content = vars.get('content')
                    timestamp = vars.get('timestamp')

                    if content != None :
                        commentobj.content=content

                    if timestamp != None :
                        commentobj.timestamp=timestamp


                    commentobj.save()
                    return Response(util.success(self,"Comment is successfully updated"))
                else:
                    return Response(util.error(self,"Comment Id Not Match"))
            else:
                return Response(util.error(self,"Enter comment id"))
            
        except Exception as e:
            return Response(util.error(self,str(e))) 
    
class LikeAPI(APIView):
    def post(self, request, format=None):
        try:
            vars = request.data
            userid = vars.get('userid')
            postid = vars.get('postid')
            like_dis = vars.get('like_dis')
        
            if userid != None and postid != None and like_dis != None:
                if UserProfile.objects.filter(id=userid).exists() and Like.objects.filter(id=postid).exists() :
                    userobj= UserProfile.objects.get(id=userid)
                    postobj= Post.objects.get(id=postid)
                
                    Like.objects.create(user=userobj,post=postobj,like_dis=like_dis)
                    return Response(util.success(self,'Like is successfully created'))
                else:
                    return Response(util.error(self,'User Id or Post Id Not Match'))
            else:
                return Response(util.error(self,'userid,postid,like_dis,timestamp is needed.'))
        except Exception as e:
            return Response(util.error(self,str(e)))

    def delete(self, request, format=None,id=None):
        try:
            if id is not None:
                if Like.objects.filter(id=id):
                    obj=Like.objects.get(id=id)
                    obj.delete()
                    return Response(util.success(self,'Like is successfully deleted'))
                else:
                    return Response(util.error(self,"Like Id Not Match"))
            else :
                likeobj=Like.objects.all().delete
                return Response(util.success(self,"Like is successfully deleted"))
        except Exception as e:
            return Response(util.error(self,str(e)))

    def get(self, request, format=None,id=None):
        try:
            if id is None :
                obj=Like.objects.all()
                serializerobj=likeSerializer(obj, many=True)
                return Response(serializerobj.data)
            else :
                if Like.objects.filter(id=id):
                    obj=Like.objects.get(id=id)
                    serializerobj=likeSerializer(obj).data
                    return Response(serializerobj)
                else:
                    return Response(util.error(self,"Like Id Not Match"))
        except Exception as e:
            return Response(util.error(self,str(e)))

    def put(self, request, format=None,id=None):
        try:
            if id is not None:
                if Like.objects.filter(id=id):
                    likeobj= Like.objects.get(id=id)
                    vars = request.data
                    userid = vars.get('userid')
                    postid = vars.get('postid')
                    like_dis = vars.get('like_dis')

                    if like_dis != None :
                        likeobj.like_dis=like_dis

                    likeobj.save()
                    return Response(util.success(self,"like is successfully updated"))
                else:
                    return Response(util.error(self,"like Id Not Match"))
            else:
                return Response(util.error(self,"Enter like id"))
            
        except Exception as e:
            return Response(util.error(self,str(e))) 



